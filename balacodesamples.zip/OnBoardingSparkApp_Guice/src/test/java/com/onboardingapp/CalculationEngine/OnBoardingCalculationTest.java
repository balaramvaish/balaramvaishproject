package com.onboardingapp.CalculationEngine;

import org.apache.spark.sql.Dataset;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import static org.junit.Assert.*;

import javax.xml.crypto.Data;
import java.io.File;

@RunWith(MockitoJUnitRunner.class)
public class OnBoardingCalculationTest {

    @InjectMocks
    OnBoardingCalculation calculation;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void transcoreMethodTest() {
        String jsonmockdata = "C:\\Users\\Girija.Gavara\\Desktop\\OnBoardingSparkApp_Guice\\src\\test\\resources\\Transaction_Core.json";
        Dataset actualtranscore_val = calculation.transcoreMethod(jsonmockdata);
        assertNotNull(actualtranscore_val);

    }

    @Test
    public void transcorelotMethod() {
        String csvmockdata = "C:\\Users\\Girija.Gavara\\Desktop\\OnBoardingSparkApp_Guice\\src\\test\\resources\\Transaction_Core_Lot.csv";
        Dataset actualtranscorelot_val = calculation.transcorelotMethod(csvmockdata,",");
        assertNotNull(actualtranscorelot_val);
    }

}