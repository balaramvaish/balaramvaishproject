package com.onboardingapp.config;

import com.google.inject.AbstractModule;
import com.onboardingapp.CalculationEngine.CalculationEngine;
import com.onboardingapp.CalculationEngine.OnBoardingCalculation;

public class AppModule extends AbstractModule {
    @Override
    protected void configure() {
        //super.configure();
        bind(CalculationEngine.class).to(OnBoardingCalculation.class);
    }
}
