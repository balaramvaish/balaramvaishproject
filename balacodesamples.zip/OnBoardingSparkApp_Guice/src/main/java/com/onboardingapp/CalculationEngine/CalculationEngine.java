package com.onboardingapp.CalculationEngine;

import org.apache.spark.sql.SparkSession;

import java.io.IOException;

public interface CalculationEngine {

    SparkSession sparksession = SparkSession
            .builder()
            .appName("OnBoardingSpark_Application").master("local[*]")
            .getOrCreate();

    void OnBoardingCalculation() throws IOException;
}
